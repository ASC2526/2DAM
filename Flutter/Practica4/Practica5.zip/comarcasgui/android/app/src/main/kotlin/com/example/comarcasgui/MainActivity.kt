package com.example.comarcasgui

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
